--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.13 (Ubuntu 10.13-1.pgdg18.04+1)
-- Dumped by pg_dump version 12.3 (Ubuntu 12.3-1.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE visit_card;
--
-- Name: visit_card; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE visit_card WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'ru_RU.UTF-8' LC_CTYPE = 'ru_RU.UTF-8';


ALTER DATABASE visit_card OWNER TO root;

\connect visit_card

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

--
-- Name: achievement; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.achievement (
    id integer NOT NULL,
    description character varying(255) NOT NULL,
    job_id integer NOT NULL
);


ALTER TABLE public.achievement OWNER TO root;

--
-- Name: education; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.education (
    id integer NOT NULL,
    direction character varying(255) NOT NULL,
    finish date,
    institute character varying(255) NOT NULL,
    start date NOT NULL
);


ALTER TABLE public.education OWNER TO root;

--
-- Name: hibernate_sequences; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.hibernate_sequences (
    sequence_name character varying(255) NOT NULL,
    next_val bigint
);


ALTER TABLE public.hibernate_sequences OWNER TO root;

--
-- Name: interest; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.interest (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.interest OWNER TO root;

--
-- Name: job; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.job (
    id integer NOT NULL,
    company character varying(255) NOT NULL,
    finish date,
    "position" character varying(255) NOT NULL,
    start date NOT NULL
);


ALTER TABLE public.job OWNER TO root;

--
-- Name: job_achievements; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.job_achievements (
    job_id integer NOT NULL,
    achievements character varying(255)
);


ALTER TABLE public.job_achievements OWNER TO root;

--
-- Name: skill; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.skill (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.skill OWNER TO root;

--
-- Data for Name: achievement; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.achievement (id, description, job_id) FROM stdin;
\.
COPY public.achievement (id, description, job_id) FROM '$$PATH$$/2946.dat';

--
-- Data for Name: education; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.education (id, direction, finish, institute, start) FROM stdin;
\.
COPY public.education (id, direction, finish, institute, start) FROM '$$PATH$$/2947.dat';

--
-- Data for Name: hibernate_sequences; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.hibernate_sequences (sequence_name, next_val) FROM stdin;
\.
COPY public.hibernate_sequences (sequence_name, next_val) FROM '$$PATH$$/2948.dat';

--
-- Data for Name: interest; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.interest (id, name) FROM stdin;
\.
COPY public.interest (id, name) FROM '$$PATH$$/2949.dat';

--
-- Data for Name: job; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.job (id, company, finish, "position", start) FROM stdin;
\.
COPY public.job (id, company, finish, "position", start) FROM '$$PATH$$/2950.dat';

--
-- Data for Name: job_achievements; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.job_achievements (job_id, achievements) FROM stdin;
\.
COPY public.job_achievements (job_id, achievements) FROM '$$PATH$$/2945.dat';

--
-- Data for Name: skill; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.skill (id, name) FROM stdin;
\.
COPY public.skill (id, name) FROM '$$PATH$$/2951.dat';

--
-- Name: achievement achievement_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.achievement
    ADD CONSTRAINT achievement_pkey PRIMARY KEY (id);


--
-- Name: education education_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.education
    ADD CONSTRAINT education_pkey PRIMARY KEY (id);


--
-- Name: hibernate_sequences hibernate_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.hibernate_sequences
    ADD CONSTRAINT hibernate_sequences_pkey PRIMARY KEY (sequence_name);


--
-- Name: interest interest_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.interest
    ADD CONSTRAINT interest_pkey PRIMARY KEY (id);


--
-- Name: job job_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.job
    ADD CONSTRAINT job_pkey PRIMARY KEY (id);


--
-- Name: skill skill_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

